<?xml version="1.0" encoding="UTF-8"?>
<tileset name="man" tilewidth="64" tileheight="128">
 <image source="../images/man.png" width="64" height="128"/>
</tileset>
