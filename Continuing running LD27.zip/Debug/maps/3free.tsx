<?xml version="1.0" encoding="UTF-8"?>
<tileset name="free" tilewidth="64" tileheight="64">
 <image source="../images/points/free.png" width="64" height="64"/>
</tileset>
