<?xml version="1.0" encoding="UTF-8"?>
<tileset name="finish" tilewidth="64" tileheight="64">
 <image source="../images/points/finish.png" width="64" height="64"/>
</tileset>
