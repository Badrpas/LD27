#include "Game_refs.h"

ObjectPointer::ObjectPointer () {
	pointer		= NULL;
	type		= O_BLOCK;
}