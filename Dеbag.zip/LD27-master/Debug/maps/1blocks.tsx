<?xml version="1.0" encoding="UTF-8"?>
<tileset name="blocks" tilewidth="64" tileheight="64">
 <image source="../images/block.png" width="64" height="64"/>
</tileset>
